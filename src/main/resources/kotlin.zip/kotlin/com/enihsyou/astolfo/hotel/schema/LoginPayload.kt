package com.enihsyou.astolfo.hotel.schema

import javax.validation.Payload

