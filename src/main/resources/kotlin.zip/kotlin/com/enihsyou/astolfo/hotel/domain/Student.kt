package com.enihsyou.astolfo.hotel.domain
import java.io.Serializable

data class Student (val student_id : Long, val student_email: String , val student_name : String , val student_passwd : String  ) : Serializable
