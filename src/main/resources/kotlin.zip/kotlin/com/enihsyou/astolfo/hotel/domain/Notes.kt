package com.enihsyou.astolfo.hotel.domain

import java.io.Serializable

data class Notes(val student_uid : Int,val note:String):Serializable
