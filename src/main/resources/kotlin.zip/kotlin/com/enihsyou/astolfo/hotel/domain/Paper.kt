package com.enihsyou.astolfo.hotel.domain

import java.io.Serializable

data class Paper(val paper_id :Int,val create_time:String,val last_modification :String):Serializable
