package com.enihsyou.astolfo.hotel.domain

import java.io.Serializable

data class QuestionPaper (val question_id :Int, val paper_id:Int, val ind:Int) : Serializable
